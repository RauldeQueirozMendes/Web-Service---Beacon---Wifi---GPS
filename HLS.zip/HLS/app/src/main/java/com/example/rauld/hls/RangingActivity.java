package com.example.rauld.hls;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import org.altbeacon.beacon.AltBeacon;
import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.MonitorNotifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
public class RangingActivity extends AppCompatActivity implements BeaconConsumer{

    protected static final String TAG = "RangingActivity";
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    public static final String ALTBEACON = "m:2-3=beac,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25";
    public static final String ALTBEACON2 = "m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24,d:25-25";
    public static final String EDDYSTONE_TLM =  "x,s:0-1=feaa,m:2-2=20,d:3-3,d:4-5,d:6-7,d:8-11,d:12-15";
    public static final String EDDYSTONE_UID = "s:0-1=feaa,m:2-2=00,p:3-3:-41,i:4-13,i:14-19";
    public static final String EDDYSTONE_URL = "s:0-1=feaa,m:2-2=10,p:3-3:-41,i:4-20v";
    public static final String IBEACON = "m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24";
    private BeaconManager beaconManager;

    WebView web;
    List<ScanResult> wifis;
    double ESPF1_=0, ESPL1_=0, ESPF2_=0, ESPL2_=0, ESPF3_=0, ESPL3_=0, latitude_=0, longitude_=0;
    double d1_=0, d2_=0, d3_=0;
    Location loc;
    LocationManager lm;
    Criteria criteria;
    String provider;
    WifiManager mWifiManager;
    Button btnWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranging);

        btnWeb = (Button) findViewById(R.id.btnWeb);

        btnWeb.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                web = (WebView) findViewById(R.id.webView);
                web.getSettings().setJavaScriptEnabled(true);

                if (web == null) { System.out.print("mWebView is null"); }
                else if (web.getSettings() == null) { System.out.print("Settings is null"); }

                web.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {

                        view.loadUrl(url);
                        return true;
                    }
                });
                web.loadUrl("http://www.robotica.ufscar.br/~raul/mapa/html/mapa.html");
            }
        });

        verifyBluetooth();
        Log.i(TAG,"Application just launched");

        beaconManager = BeaconManager.getInstanceForApplication(this);

        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(BeaconParser.URI_BEACON_LAYOUT));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(BeaconParser.EDDYSTONE_URL_LAYOUT));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(BeaconParser.EDDYSTONE_UID_LAYOUT));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(BeaconParser.EDDYSTONE_TLM_LAYOUT));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(BeaconParser.ALTBEACON_LAYOUT));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(ALTBEACON2));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(IBEACON));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(ALTBEACON));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(EDDYSTONE_TLM));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(EDDYSTONE_UID));
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout(EDDYSTONE_URL));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android M Permission check
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("This app needs location access");
                builder.setMessage("Please grant location access so this app can detect beacons in the background.");
                builder.setPositiveButton(android.R.string.ok, null);
                builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                    @TargetApi(23)
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                                PERMISSION_REQUEST_COARSE_LOCATION);
                    }

                });
                builder.show();
            }
        }

        web = (WebView) findViewById(R.id.webView);
        web.getSettings().setJavaScriptEnabled(true);

        if (web == null) { System.out.print("mWebView is null"); }
        else if (web.getSettings() == null) { System.out.print("Settings is null"); }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                view.loadUrl(url);
                return true;
            }
        });
        web.loadUrl("http://www.robotica.ufscar.br/~raul/mapa/html/mapa.html");

        beaconManager.bind(this);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    // To handle "Back" key press event for WebView to go back to previous screen.
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    class SendBeaconUpdateToServer extends AsyncTask<Double, Double, Void> {

        @Override
        protected Void doInBackground(Double... pParams) {

                try {

                    double d1 = pParams[0];
                    double d2 = pParams[1];
                    double d3 = pParams[2];
                    double espf1 = pParams[3];
                    double espf2 = pParams[4];
                    double espf3 = pParams[5];
                    double espl1 = pParams[6];
                    double espl2 = pParams[7];
                    double espl3 = pParams[8];
                    double latitude = pParams[9];
                    double longitude = pParams[10];

                    Log.e(TAG, "Enviando para o servidor...");
                    URL url = new URL("http://www.robotica.ufscar.br/~raul/mapa/html/DataUpdate.php?d1="
                            + d1 + "&d2=" + d2 + "&d3=" + d3 + "&espf1="
                            + espf1 + "&espf2=" + espf2 + "&espf3=" + espf3 +
                            "&espl1=" + espl1 + "&espl2=" + espl2 + "&espl3=" + espl3
                            + "&latitude=" + latitude + "&longitude=" + longitude);
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.getContent();
                    urlConnection.disconnect();
                }
                catch (MalformedURLException ex) {
                    Log.e(TAG, Log.getStackTraceString(ex));
                }
                catch (IOException ex) {
                    Log.e(TAG, Log.getStackTraceString(ex));
                }
            return null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "coarse location permission granted");
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Functionality limited");
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons when in the background.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                        @Override
                        public void onDismiss(DialogInterface dialog) {
                        }

                    });
                    builder.show();
                }
                return;
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        beaconManager.unbind(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (beaconManager.isBound(this)) beaconManager.setBackgroundMode(true);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (beaconManager.isBound(this)) beaconManager.setBackgroundMode(false);
    }

    @Override
    public void onBeaconServiceConnect(){

        beaconManager.addRangeNotifier(new RangeNotifier() {

            @SuppressLint("MissingPermission")
            @Override
            public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {
                if (beacons.size() > 0) {

                    Beacon firstBeacon = beacons.iterator().next();

                    mWifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

                    mWifiManager.startScan();

                    registerReceiver(new BroadcastReceiver(){
                        @Override
                        public void onReceive(Context context, Intent intent) {
                            // TODO Auto-generated method stub
                            //Log.i(TAG, "opening wifimanager");
                            wifis = mWifiManager.getScanResults();
                            for(ScanResult i : wifis) {
                                if(i.SSID.equals("ESP1")){ESPF1_ = i.frequency; ESPL1_ = i.level;}
                                if(i.SSID.equals("AI-THINKER_D59F54")){ESPF2_ = i.frequency; ESPL2_ = i.level;}
                                if(i.SSID.equals("AI-THINKER_D5963B")){ESPF3_ = i.frequency; ESPL3_  = i.level;}
                            }
                        }
                    }, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));

                    lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

                    // Define the criteria how to select the location provider
                    criteria = new Criteria();
                    criteria.setAccuracy(Criteria.ACCURACY_COARSE);   //default

                    // user defines the criteria
                    criteria.setCostAllowed(false);

                    // get the best provider depending on the criteria
                    provider = lm.getBestProvider(criteria, false);

                    loc = lm.getLastKnownLocation(provider);

                    if(loc != null) {
                        longitude_ = (double) loc.getLongitude();
                        latitude_ = (double) loc.getLatitude();
                    }


                    switch (firstBeacon.hashCode())
                    {
                        case -1981497973: //40
                            d1_ = (double) firstBeacon.getDistance();
                            break;

                        case 1994704298: //6A
                            d2_ = (double) firstBeacon.getDistance();
                            break;

                        case -1865301374: //B3
                            d3_ = (double) firstBeacon.getDistance();
                            break;
                    }



                    /*logToDisplay("\n" + String.format("%.5f", d1) + "; " + String.format("%.5f", d2)
                            + "; " + String.format("%.5f", d3) +"; " + String.format("%.5f", ESPF1)
                            + "; " + String.format("%.5f", ESPF2) + "; " + String.format("%.5f", ESPF3)
                            + "; " + String.format("%.5f", ESPL1) + "; " + String.format("%.5f", ESPL2)
                            + "; " + String.format("%.5f", ESPL3) + "; " + String.format("%.7f", latitude)
                            + "; " + String.format("%.7f", longitude) + "; ");*/

                    double[] params = {0,0,0,0,0,0,0,0,0,0,0};
                      params[0] = d1_;
                      params[1] = d2_;
                      params[2] = d3_;
                      params[3] = ESPF1_;
                      params[4] = ESPF2_;
                      params[5] = ESPF3_;
                      params[6] = ESPL1_;
                      params[7] = ESPL2_;
                      params[8] = ESPL3_;
                      params[9] = latitude_;
                      params[10] = longitude_;

                    new SendBeaconUpdateToServer().execute(new Double(params[0]), new Double(params[1]),
                              new Double(params[2]), new Double(params[3]), new Double(params[4]),
                              new Double(params[5]), new Double(params[6]), new Double(params[7]),
                              new Double(params[8]), new Double(params[9]), new Double(params[10]));
                }
            }
        });
        try {
            beaconManager.startRangingBeaconsInRegion(new Region("myRangingUniqueId", null, null, null));

        } catch (RemoteException e) {
            e.printStackTrace();
        }

        beaconManager.addMonitorNotifier(new MonitorNotifier() {
            @Override
            public void didEnterRegion(Region region) {
                Log.i(TAG, "I just saw an beacon for the first time!");
            }

            @Override
            public void didExitRegion(Region region) {
                Log.i(TAG, "I no longer see an beacon");
            }

            @Override
            public void didDetermineStateForRegion(int state, Region region) {
                Log.i(TAG, "I have just switched from seeing/not seeing beacons: " + state);
            }
        });

        try {
            beaconManager.startMonitoringBeaconsInRegion(new Region("myMonitoringUniqueId", null, null, null));
        } catch (RemoteException e) {}
    }

    private void verifyBluetooth() {

        try {
            if (!BeaconManager.getInstanceForApplication(this).checkAvailability()) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Bluetooth not enabled");
                builder.setMessage("Please enable bluetooth in settings and restart this application.");
                builder.setPositiveButton(android.R.string.ok, null);
                builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        //finish();
                        //System.exit(0);
                    }
                });
                builder.show();
            }
        }
        catch (RuntimeException e) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Bluetooth LE not available");
            builder.setMessage("Sorry, this device does not support Bluetooth LE.");
            builder.setPositiveButton(android.R.string.ok, null);
            builder.setOnDismissListener(new DialogInterface.OnDismissListener() {

                @Override
                public void onDismiss(DialogInterface dialog) {
                    finish();
                    System.exit(0);
                }

            });
            builder.show();
        }
    }
}